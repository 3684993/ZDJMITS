import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const require=createRequire('D:/MITS/package.json');
const ts=require('typescript');
const repo=path.resolve('work/audit-main'), dest=path.resolve('work/repro-modules');fs.mkdirSync(dest,{recursive:true});
const specs={operationalIncidents:'apps/engine/src/services/operationalIncidents.ts',historicalTpReachability:'apps/engine/src/services/historicalTpReachability.ts',quantityHorizonCandidates:'apps/engine/src/services/quantityHorizonCandidates.ts',v397FrozenSizing:'apps/engine/src/services/v397FrozenSizing.ts',tradingCost:'packages/core/src/tradingCost.ts'};
specs.BinanceMarketStream='apps/engine/src/adapters/market/BinanceMarketStream.ts';specs.recentTradePrices='apps/engine/src/adapters/market/recentTradePrices.ts';
for(const [name,file] of Object.entries(specs)){
 let source=fs.readFileSync(path.join(repo,file),'utf8').replaceAll("from '@zdj/core'","from './tradingCost.mjs'");
 source=source.replace("import WebSocket from 'ws';","const WebSocket={OPEN:1};");
 for(const n of Object.keys(specs))source=source.replaceAll(`'./${n}.js'`,`'./${n}.mjs'`);
 fs.writeFileSync(path.join(dest,name+'.mjs'),ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ES2022,target:ts.ScriptTarget.ES2022}}).outputText);
}
const inc=await import(pathToFileURL(path.join(dest,'operationalIncidents.mjs')).href);
const reach=await import(pathToFileURL(path.join(dest,'historicalTpReachability.mjs')).href);
const qty=await import(pathToFileURL(path.join(dest,'quantityHorizonCandidates.mjs')).href);
const result={};
const {BinanceMarketStream}=await import(pathToFileURL(path.join(dest,'BinanceMarketStream.mjs')).href);
const stream=new BinanceMarketStream({},async()=>{throw new Error('NETWORK_DISABLED');});stream.updateSymbols(['BTCUSDT']);
const point=Date.now();stream.onEvent({e:'24hrTicker',s:'BTCUSDT',c:'100',q:'100000',P:'0',n:'10',E:point-60_000},'MARKET');stream.onEvent({e:'markPriceUpdate',s:'BTCUSDT',p:'100',i:'100',E:point-60_000},'MARKET');stream.onEvent({e:'bookTicker',s:'BTCUSDT',b:'100',a:'101',E:point},'PUBLIC');
result.staleFieldsAfterFreshBookTicker=stream.quote('BTCUSDT');assert.equal(result.staleFieldsAfterFreshBookTicker.mark,100);assert.equal(result.staleFieldsAfterFreshBookTicker.ts,point);
stream.onEvent({e:'bookTicker',s:'BTCUSDT',b:'98',a:'99',E:point-1000},'PUBLIC');result.outOfOrderQuote=stream.quote('BTCUSDT');assert.equal(result.outOfOrderQuote.bid,98);
result.privateSingleTimeout=inc.operationalCandidates({pipeline:{pipelineState:'RUNNING',freshMarkets:{status:'FRESH'}},routes:[],account:{status:'UNAVAILABLE',reason:'BINANCE_TRANSPORT_BLOCKED: Binance request timed out'}});
assert.equal(result.privateSingleTimeout[0].publicCode,'NET-002');
const tracker=new inc.OperationalIncidentTracker(), candidate=inc.classifyOperationalError({message:'Binance request timed out',subsystem:'BINANCE_HTTP',routeIdentity:'proxy-test'});
const recovered=[];
for(let i=0;i<5;i++){
 tracker.observe([candidate],i*100+1);const before=new Set(tracker.read().active.map(r=>r.incidentId));const current=tracker.observe([],i*100+2),after=new Set(current.active.map(r=>r.incidentId));
 recovered.push(current.history.filter(r=>before.has(r.incidentId)&&!after.has(r.incidentId)).length);
}
result.routerRecoveryPublications=recovered;assert.deepEqual(recovered,[1,2,3,4,5]);
const now=Date.now();const irregular=Array.from({length:80},(_,i)=>({openTime:now-(80-i)*10*60_000,closeTime:now-(80-i)*10*60_000+59_999,open:100,close:100,high:102,low:98,isClosed:true}));irregular.at(-1).closeTime=now-1000;
result.irregularReachability=reach.evaluateTargetReachability({rows:irregular,side:'LONG',horizonMinutes:15,targetMovePercent:1,lookbackBars:120,minSamples:30,now});assert.equal(result.irregularReachability.status,'READY');
const takeProfit={entryFeeRate:.0004,takerFeeRate:.0004,makerFeeRate:.0002,exitFeeAssumption:'TAKER',slippageBufferPct:0,feeSafetyBufferPct:10,minNetProfitUsd:1,minNetProfitRoiPct:.15};
const base={symbol:'BTCUSDT',side:'LONG',now,quote:{bid:100,ask:100.01,tickSize:.01,stepSize:.01,minQty:.01,minNotional:5},leverage:10,candidateSchemaVersion:'V397-PLAN-CANDIDATE-1',envelope:{maxQuantityUnits:5000,maxNotionalUsd:5000,maxMarginUsd:500,executable:true,minimumInitialMarginQuote:100,minimumOrderNotionalQuote:200},envelopeExpiresAt:now+60_000,factVersion:'audit',risk:null,settings:{takeProfit,tradeEconomics:{admissionMode:'ENFORCE',historicalTpReachabilityEnabled:false,reachabilityMinSamples:30}},candles:()=>[],targetHorizons:[15,60,240],managementDurationMs:3600_000};
const none=qty.buildQuantityHorizonCandidates(base);result.disabledReachabilityMissingHistory={noTradeReasons:none.noTradeReasons,total:none.candidates.length,executable:none.candidates.filter(c=>c.executable).length,blockers:[...new Set(none.candidates.flatMap(c=>c.blockers))]};assert(result.disabledReachabilityMissingHistory.executable>0);
const populated=qty.buildQuantityHorizonCandidates({...base,candles:()=>irregular});result.sampleEconomics=populated.candidates.slice(0,2).map(c=>({economics:c.economics,costs:c.costs,marginUsd:c.marginUsd}));
const beyond=qty.buildQuantityHorizonCandidates({...base,candles:()=>irregular,selection:{quantityUnits:1500,targetPrice:110,targetHorizonMinutes:15}});result.disabledReachabilityBeyondTarget={selection:beyond.selection,noTradeReasons:beyond.noTradeReasons};assert.equal(beyond.selection.offered,false);assert(beyond.selection.refusals.some(s=>s.startsWith('CANDIDATE_TARGET_BEYOND_STATISTICAL_BOUND')));
fs.writeFileSync('work/evidence/repros.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
