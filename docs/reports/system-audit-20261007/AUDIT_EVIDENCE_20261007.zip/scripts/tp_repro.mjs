import fs from 'node:fs';import {createRequire} from 'node:module';import {pathToFileURL} from 'node:url';import assert from 'node:assert/strict';
const ts=createRequire('D:/MITS/package.json')('typescript');
let source=fs.readFileSync('work/audit-main/apps/engine/src/services/tpGuardian.ts','utf8').replace(/^import .*;\r?\n/gm,'');
source=`const V396ExitRuntime={quantityUnitsOf:(q,s)=>Math.round(q/s)};const exitSubjectFromPosition=p=>p;\n`+fs.readFileSync('work/audit-main/apps/engine/src/services/tpSubmissionOutcome.ts','utf8')+'\n'+source;
const target='work/repro-modules/tpGuardian.mjs';fs.writeFileSync(target,ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ES2022,target:ts.ScriptTarget.ES2022}}).outputText);
const {TpGuardian}=await import(pathToFileURL(fs.realpathSync(target)).href);const results=[];
for(const remoteStatus of ['CANCELED','EXPIRED','REJECTED']){
 const state={positions:new Map([['p',{id:'p',symbol:'BTCUSDT',side:'LONG',cycleId:'cycle',quantity:1,openedAt:1}]]),tpOrders:new Map(),settings:{settingsVersion:247},runtimeControl:{capital:{generation:1}}};
 const exchange={proveReduction:async()=>({kind:'ONE_WAY_REDUCE_ONLY',checkedAt:Date.now(),positionSide:'LONG',liveQuantity:1}),findExitByClientOrderId:async()=>({state:'FOUND',order:{status:remoteStatus,originalQuantity:1,executedQuantity:0,exchangeOrderId:'old-order'}}),placeTakeProfit:async()=>{throw new Error('SIMULATED_ACK_LOSS_NO_NETWORK')}};
 const reports=[];const exit={mandate:()=>null,ensureGuardianMandate:()=>({version:1}),prepareTakeProfit:async()=>({clientOrderId:'audit-client',accepted:true,submitRequired:true,reasons:[]}),registerExitProvenance:()=>{},transitionByClientOrderId:()=>true,jitBeforeSubmit:()=>({allowed:true}),recordExitOrderReport:(...v)=>reports.push(v)};
 const guard=new TpGuardian(state,exchange,{publish:()=>{}},exit);const actual=await guard.place({id:'tp',positionId:'p',symbol:'BTCUSDT',side:'SELL',quantity:1,price:110,status:'NEW',cycleId:'cycle'},{stepSize:.001,tickSize:.01});
 assert.equal(actual.status,'WORKING');results.push({remoteStatus,adoptedStatus:actual.status,durableReportStatus:reports[0][1].status});
}
let budget=fs.readFileSync('work/audit-main/apps/engine/src/adapters/binance/requestBudget.ts','utf8');fs.writeFileSync('work/repro-modules/requestBudget.mjs',ts.transpileModule(budget,{compilerOptions:{module:ts.ModuleKind.ES2022,target:ts.ScriptTarget.ES2022}}).outputText);
const {binanceBudgetLane}=await import(pathToFileURL(fs.realpathSync('work/repro-modules/requestBudget.mjs')).href);assert.equal(binanceBudgetLane('BACKGROUND'),'MARKET_PUBLIC');
fs.writeFileSync('work/evidence/tp-repro.json',JSON.stringify({tpTerminalAdoption:results,backgroundSourceLane:binanceBudgetLane('BACKGROUND')},null,2));console.log(JSON.stringify({tpTerminalAdoption:results,backgroundSourceLane:binanceBudgetLane('BACKGROUND')},null,2));
